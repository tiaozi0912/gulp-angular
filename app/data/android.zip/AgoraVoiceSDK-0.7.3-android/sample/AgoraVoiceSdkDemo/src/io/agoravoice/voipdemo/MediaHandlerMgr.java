package io.agoravoice.voipdemo;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.CopyOnWriteArraySet;

import android.os.Message;
import io.agoravoice.voiceengine.IAudioEventHandler;

public class MediaHandlerMgr implements IAudioEventHandler {

	private CopyOnWriteArraySet<MediaHandler> mHandlers = new CopyOnWriteArraySet<MediaHandler>();

	public void add(MediaHandler handler) {
		mHandlers.add(handler);
	}

	public void remove(MediaHandler handler) {
		mHandlers.remove(handler);
	}

	public boolean notify2UIThread(int message) {
		return notify2UIThread(message, (Object[]) null);
	}

	public boolean notify2UIThread(int message, Object... params) {
		for (MediaHandler handler : mHandlers) {
			if (handler.canHandleMessage(message)) {
				Message msg = handler.obtainMessage();
				msg.what = message;
				msg.obj = params;
				handler.sendMessage(msg);
			}
		}
		return true;
	}

	@Override
	public void onLogEvent(byte[] evt) {
		try {
			String strLog = new String(evt, "ISO-8859-1");
			notify2UIThread(MediaMessage.onWriteLog, strLog);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onError(int arg0) {
                notify2UIThread(MediaMessage.onWriteLog, "Agora Voice SDK report error: " + arg0);
	}

	@Override
	public void onJoinSuccess(int sid, int uid) {
		notify2UIThread(MediaMessage.onWriteLog, "Channel joined: sid " + (sid&0xFFFFFFFFL) + " uid " + (uid&0xFFFFFFFFL));
	}
	
	@Override
	public void onLeaveChannel(SessionStats stats) {
		notify2UIThread(MediaMessage.onWriteLog, "end of call: duration "+stats.totalDuration + " secs, total " + stats.totalBytes + " bytes");
	}

	@Override
	public void onUpdateSessionStats(SessionStats stats) {
	}
	@Override
	public void onLoadAudioEngineSuccess() {
        notify2UIThread(MediaMessage.onWriteLog, "Agora audio engine loaded and call started");
	}

	@Override
        public void onQuality(int uid, short delay, short jitter, short lost, short lost2) {
                String msg = String.format("user %d delay %d jitter %d lost %d lost2 %d", (uid&0xFFFFFFFFL), delay, jitter, lost, lost2);
		notify2UIThread(MediaMessage.onWriteLog, msg);
	}
	@Override
	public void onUserOffline(int uid) {
        notify2UIThread(MediaMessage.onWriteLog, "user " + (uid&0xFFFFFFFFL) + " is offline");
	}
	@Override
	public void onRecapStat(byte[] recap) {
		
	}
	@Override
	public void onSpeakersReport(SpeakerInfo[] speakers, int mixVolume) {
	}
}

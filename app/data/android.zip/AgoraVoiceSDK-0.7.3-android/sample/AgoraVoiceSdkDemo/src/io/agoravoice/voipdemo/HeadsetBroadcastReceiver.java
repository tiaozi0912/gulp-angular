package io.agoravoice.voipdemo;

import io.agoravoice.voiceengine.AgoraAudio.AudioOutputRouting;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class HeadsetBroadcastReceiver extends BroadcastReceiver {

	private static final String LOG_TAG = AgoraVoiceSdkDemo.class.getSimpleName();
	private Activity mActivity;

	public HeadsetBroadcastReceiver(Activity activity) {
		mActivity = activity;
	}
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equalsIgnoreCase(Intent.ACTION_HEADSET_PLUG)) {
            // http://developer.android.com/reference/android/content/Intent.html#ACTION_HEADSET_PLUG
            if (intent.hasExtra("state")) {
                int plugged = intent.getIntExtra("state", -1);
				MediaDemoApplication app = (MediaDemoApplication) mActivity.getApplication();
                if (plugged == 1) {
					Log.i(LOG_TAG, "Set audio output to headset");
    				app.getAgoraAudio().setAudioOutputRouting(AudioOutputRouting.Headset);                	
                } else if (plugged == 0) {
                	((AgoraVoiceSdkDemo)mActivity).setAudioOutput();
                } else {
					Log.i(LOG_TAG, "illegal state from ACTION_HEADSET_PLUG");
                }
            }
        }
    }
}

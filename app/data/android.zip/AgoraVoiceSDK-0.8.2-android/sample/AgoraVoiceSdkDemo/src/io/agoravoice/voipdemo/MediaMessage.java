package io.agoravoice.voipdemo;

public class MediaMessage {
	public static final int onJoinRes = 1000;
	public static final int onWriteLog = 1001;
}

//
//  ViewController.m
//  sample
//
//  Created by kele on 14-6-8.
//  Copyright (c) 2014年 kele. All rights reserved.
//

#import "ViewController.h"
#import <AgoraAudioKit/AgoraAudioKit.h>

@interface ViewController () <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UILabel *keyLabel;

@property (weak, nonatomic) IBOutlet UIButton *joinButton;
@property (weak, nonatomic) IBOutlet UIButton *leaveButton;
@property (weak, nonatomic) IBOutlet UIButton *muteSwitchButton;
@property (weak, nonatomic) IBOutlet UIButton *speakerSwitchButton;
@property (weak, nonatomic) IBOutlet UITextView *logMessageTextView;

@property (strong, nonatomic) NSMutableString *logString;

@property (strong ,nonatomic) AgoraAudioKit *agoraAudio;

@property (assign, nonatomic) BOOL hasJoinedChannel;
@property (assign, nonatomic) BOOL hasMuted;
@property (assign, nonatomic) BOOL enabledSpeaker;
@end

@implementation ViewController
- (NSMutableString *)logString
{
    if (!_logString) {
        _logString = [[NSMutableString alloc] init];
    }
    return _logString;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    __weak typeof(self) weakSelf = self;
    self.agoraAudio = [[AgoraAudioKit alloc] initWithQuality:^(NSUInteger uid, NSUInteger delay, NSUInteger jitter, NSUInteger lost, NSUInteger lost2) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        [strongSelf appendLogString:[NSString stringWithFormat:@"user %u delay %u jitter %u lost %u lost2 %u", (unsigned int)uid, (unsigned int)delay, (unsigned int)jitter, (unsigned int)lost, (unsigned int)lost2]];
    }error:^(AgoraAudioErrorCode errorCode) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        [strongSelf appendLogString:[NSString stringWithFormat:@"error code: %lu", (long)errorCode]];
    }];
    
    NSURL *docURL = [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
    NSString *logDir = [docURL path];
//    NSString *logDir = NSSearchPathForDirectoriesInDomains(NSCachesDirectory,NSUserDomainMask, YES).firstObject;
    
    NSString *logTextPath = [logDir stringByAppendingPathComponent:@"com.agora.CacheLogs/agorasdk.log"];
    NSDictionary *profileDic = @{@"mediaSdk": @{@"logFile": logTextPath}};
    NSData *profileData = [NSJSONSerialization dataWithJSONObject:profileDic options:0 error:NULL];
    NSString *profileString = [[NSString alloc] initWithData:profileData encoding:NSUTF8StringEncoding];
    

    [self.agoraAudio setProfile:profileString merge:true];
}

- (void)setHasJoinedChannel:(BOOL)hasJoinedChannel
{
    _hasJoinedChannel = hasJoinedChannel;
    
    self.joinButton.hidden = hasJoinedChannel;
    self.leaveButton.hidden = ! hasJoinedChannel;
    self.muteSwitchButton.hidden = ! hasJoinedChannel;
    self.speakerSwitchButton.hidden = ! hasJoinedChannel;
    
    [[UIDevice currentDevice] setProximityMonitoringEnabled:hasJoinedChannel];
}

- (void)appendLogString:(NSString *)logString
{
    [self.logString appendFormat:@"%@\n", logString];
    
    self.logMessageTextView.text = self.logString;
    [self.logMessageTextView scrollRangeToVisible:NSMakeRange(self.logString.length, 0)];
}

- (void)clearLogTextView
{
    self.logMessageTextView.text = nil;
    self.logString = nil;
}

- (void)joinChannel:(NSString *)channelName
{
    if (! channelName.length) {
        [self appendLogString:@"no channel name!"];
        return;
    }
    
    if(self.hasJoinedChannel) {
        [self appendLogString:@"join channel already,  leave first!"];
        return;
    }
    
    [self clearLogTextView];
    self.joinButton.enabled = NO;
    self.joinButton.alpha = 0.1f;
    [self appendLogString:@"join Channel begin"];
    
    __weak typeof(self) weakSelf = self;
    [self.agoraAudio joinChannelByKey:self.keyLabel.text channelName:channelName info:@"iPhone" uid:0 success:^(NSUInteger sid, NSUInteger uid){
        weakSelf.hasJoinedChannel = YES;
        weakSelf.joinButton.enabled = YES;
        weakSelf.joinButton.alpha = 1.0f;
        __strong typeof(weakSelf) strongSelf = weakSelf;
        [strongSelf appendLogString:[NSString stringWithFormat:@"joined channel: sid %u uid %u", (unsigned int)sid, (unsigned int)uid]];
    }];
}

- (IBAction)joinPressed:(id)sender
{
    [self joinChannel:self.nameTextField.text];
}

- (IBAction)leavePressed:(id)sender
{
    if(! self.hasJoinedChannel) {
        [self appendLogString:@"not in channel!"];
        return;
    }
    
    [self.agoraAudio leaveChannel];
    self.hasJoinedChannel = NO;
    
    [self clearLogTextView];
}

- (IBAction)mutePressed:(UIButton *)sender
{
    if(! self.hasJoinedChannel) {
        [self appendLogString:@"not in channel!"];
        return;
    }
    
    [self.agoraAudio setMute:!self.hasMuted];
    self.hasMuted = !self.hasMuted;
    
    [self.muteSwitchButton setTitle:(self.hasMuted ? @"unMute" : @"mute") forState:UIControlStateNormal];
}

- (IBAction)speakerPressed:(UIButton *)sender
{
    if(! self.hasJoinedChannel) {
        [self appendLogString:@"not in channel!"];
        return;
    }
    
    [self.agoraAudio setEnableSpeaker:!self.enabledSpeaker];
    self.enabledSpeaker = !self.enabledSpeaker;
    
    [self.speakerSwitchButton setTitle:(self.enabledSpeaker ? @"disable speaker" : @"enable speaker") forState:UIControlStateNormal];
}

#pragma mark - textField delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return (! self.hasJoinedChannel);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self joinChannel:textField.text];
    
    return YES;
}
@end

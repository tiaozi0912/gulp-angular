//
//  AppDelegate.h
//  sample
//
//  Created by kele on 14-6-8.
//  Copyright (c) 2014年 kele. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
